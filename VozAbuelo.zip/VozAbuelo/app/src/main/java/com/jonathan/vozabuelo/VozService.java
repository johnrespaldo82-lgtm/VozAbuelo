package com.jonathan.vozabuelo;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Servicio de accesibilidad:
 *  1. Detecta cuando hay un campo de texto activo (WhatsApp, Google, mensajes, etc.)
 *  2. Muestra una burbuja flotante con micrófono.
 *  3. Al tocarla, escucha y escribe lo que se dijo en ese campo.
 */
public class VozService extends AccessibilityService {

    private static final String IDIOMA = "es-MX";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private LinearLayout overlay;      // contenedor: [etiqueta][burbuja]
    private FrameLayout burbuja;
    private TextView etiqueta;
    private WindowManager.LayoutParams params;
    private boolean visible = false;

    private SpeechRecognizer recognizer;
    private boolean escuchando = false;
    private AccessibilityNodeInfo campoDestino;

    private final Runnable revisarFoco = this::revisarFoco;
    private final Runnable ocultarEtiqueta = () -> {
        if (!escuchando && etiqueta != null) etiqueta.setVisibility(View.GONE);
    };

    // ---------------------------------------------------------------- ciclo de vida

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        crearBurbuja();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Esperamos un poquito para no parpadear con cada evento
        handler.removeCallbacks(revisarFoco);
        handler.postDelayed(revisarFoco, 200);
    }

    @Override
    public void onInterrupt() {
        detenerEscucha();
    }

    @Override
    public void onDestroy() {
        detenerEscucha();
        if (overlay != null && visible) {
            try { wm.removeView(overlay); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }

    // ---------------------------------------------------------------- burbuja

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private void crearBurbuja() {
        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.HORIZONTAL);
        overlay.setGravity(Gravity.CENTER_VERTICAL);

        etiqueta = new TextView(this);
        etiqueta.setTextColor(0xFFFFFFFF);
        etiqueta.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        etiqueta.setBackgroundResource(R.drawable.label_bg);
        etiqueta.setPadding(dp(14), dp(10), dp(14), dp(10));
        etiqueta.setMaxWidth(dp(240));
        etiqueta.setVisibility(View.GONE);
        LinearLayout.LayoutParams lpEt = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lpEt.rightMargin = dp(8);
        overlay.addView(etiqueta, lpEt);

        burbuja = new FrameLayout(this);
        burbuja.setBackgroundResource(R.drawable.bubble_idle);
        burbuja.setElevation(dp(6));
        ImageView mic = new ImageView(this);
        mic.setImageResource(R.drawable.ic_mic);
        FrameLayout.LayoutParams lpMic = new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER);
        burbuja.addView(mic, lpMic);
        burbuja.setContentDescription("Dictar por voz");
        overlay.addView(burbuja, new LinearLayout.LayoutParams(dp(76), dp(76)));

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                // NOT_FOCUSABLE: así el teclado y el campo de texto no pierden el foco
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        params.x = dp(8);
        params.y = (int) (dm.heightPixels * 0.30f);

        burbuja.setOnTouchListener(new ArrastrarOTocar());
    }

    /** Permite mover la burbuja arrastrándola; si solo se toca, inicia/detiene el dictado. */
    private class ArrastrarOTocar implements View.OnTouchListener {
        private int startX, startY;
        private float touchX, touchY;
        private boolean movido;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX = params.x; startY = params.y;
                    touchX = e.getRawX(); touchY = e.getRawY();
                    movido = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - touchX, dy = e.getRawY() - touchY;
                    if (Math.abs(dx) > dp(10) || Math.abs(dy) > dp(10)) movido = true;
                    if (movido) {
                        params.x = startX - (int) dx; // gravity END: x crece hacia la izquierda
                        params.y = startY + (int) dy;
                        if (visible) wm.updateViewLayout(overlay, params);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!movido) alTocarBurbuja();
                    return true;
            }
            return false;
        }
    }

    private void mostrar() {
        if (visible || overlay == null) return;
        try {
            wm.addView(overlay, params);
            visible = true;
        } catch (Exception ignored) { }
    }

    private void ocultar() {
        if (!visible || escuchando) return;
        try { wm.removeView(overlay); } catch (Exception ignored) { }
        visible = false;
    }

    /** Muestra la burbuja solo si hay un campo de texto editable con el foco. */
    private void revisarFoco() {
        if (escuchando) return;
        AccessibilityNodeInfo campo = campoActivo();
        if (campo != null) mostrar(); else ocultar();
    }

    private AccessibilityNodeInfo campoActivo() {
        try {
            AccessibilityNodeInfo foco = findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if (foco != null && foco.isEditable()
                    && !getPackageName().contentEquals(String.valueOf(foco.getPackageName()))) {
                return foco;
            }
        } catch (Exception ignored) { }
        return null;
    }

    private void mostrarEtiqueta(String texto, long autoOcultarMs) {
        etiqueta.setText(texto);
        etiqueta.setVisibility(View.VISIBLE);
        handler.removeCallbacks(ocultarEtiqueta);
        if (autoOcultarMs > 0) handler.postDelayed(ocultarEtiqueta, autoOcultarMs);
    }

    // ---------------------------------------------------------------- voz

    private void alTocarBurbuja() {
        if (escuchando) {
            // Segundo toque: terminar y escribir lo que lleva
            if (recognizer != null) recognizer.stopListening();
            return;
        }
        iniciarEscucha();
    }

    private void iniciarEscucha() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Falta dar permiso de micrófono", Toast.LENGTH_LONG).show();
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            mostrarEtiqueta("Este teléfono no tiene reconocimiento de voz. Instala o actualiza la app de Google.", 5000);
            return;
        }

        campoDestino = campoActivo();
        if (campoDestino == null) {
            mostrarEtiqueta("Primero toca donde quieres escribir", 3000);
            return;
        }

        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new Oyente());

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, IDIOMA);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, IDIOMA);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        // Dar más tiempo a las pausas (personas mayores hablan con calma). Algunos teléfonos lo ignoran.
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L);

        escuchando = true;
        burbuja.setBackgroundResource(R.drawable.bubble_listening);
        mostrarEtiqueta("Te escucho… habla", 0);
        recognizer.startListening(intent);
    }

    private void detenerEscucha() {
        escuchando = false;
        if (burbuja != null) burbuja.setBackgroundResource(R.drawable.bubble_idle);
        if (recognizer != null) {
            try { recognizer.destroy(); } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    private class Oyente implements RecognitionListener {
        @Override public void onReadyForSpeech(Bundle b) { }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float rms) {
            // Pequeño "latido" de la burbuja según el volumen de la voz
            float s = 1f + Math.max(0f, Math.min(rms, 10f)) / 50f;
            burbuja.setScaleX(s); burbuja.setScaleY(s);
        }
        @Override public void onBufferReceived(byte[] buffer) { }
        @Override public void onEndOfSpeech() {
            burbuja.setScaleX(1f); burbuja.setScaleY(1f);
        }
        @Override public void onEvent(int type, Bundle b) { }

        @Override
        public void onPartialResults(Bundle b) {
            String t = primero(b);
            if (!TextUtils.isEmpty(t)) mostrarEtiqueta(t, 0);
        }

        @Override
        public void onResults(Bundle b) {
            String t = primero(b);
            detenerEscucha();
            if (TextUtils.isEmpty(t)) {
                mostrarEtiqueta("No te escuché, intenta otra vez", 3000);
                return;
            }
            boolean ok = escribir(t);
            mostrarEtiqueta(ok ? "✔ " + t : "Copiado: mantén presionado el campo y elige Pegar", 3500);
        }

        @Override
        public void onError(int error) {
            detenerEscucha();
            burbuja.setScaleX(1f); burbuja.setScaleY(1f);
            String msg;
            switch (error) {
                case SpeechRecognizer.ERROR_NO_MATCH:
                case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                    msg = "No te escuché, intenta otra vez"; break;
                case SpeechRecognizer.ERROR_NETWORK:
                case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                    msg = "Sin internet. Revisa la conexión"; break;
                case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                    msg = "Falta el permiso de micrófono"; break;
                case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                    msg = "Espera un segundo y vuelve a tocar"; break;
                default:
                    msg = "No se pudo escuchar (error " + error + ")";
            }
            mostrarEtiqueta(msg, 3000);
        }
    }

    private static String primero(Bundle b) {
        if (b == null) return null;
        ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return (r == null || r.isEmpty()) ? null : r.get(0);
    }

    // ---------------------------------------------------------------- escribir en el campo

    /** Agrega el texto al final del campo. Devuelve false si tuvo que usar el portapapeles. */
    private boolean escribir(String dicho) {
        AccessibilityNodeInfo campo = campoActivo();
        if (campo == null) campo = campoDestino;
        if (campo == null) { copiar(dicho); return false; }
        try { campo.refresh(); } catch (Exception ignored) { }

        String actual = "";
        CharSequence cs = campo.getText();
        boolean esPista = Build.VERSION.SDK_INT >= 26 && campo.isShowingHintText();
        if (cs != null && !esPista) actual = cs.toString();

        String nuevo;
        if (actual.isEmpty()) {
            nuevo = mayusculaInicial(dicho);
        } else {
            boolean terminaEnEspacio = Character.isWhitespace(actual.charAt(actual.length() - 1));
            nuevo = actual + (terminaEnEspacio ? "" : " ") + dicho;
        }

        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, nuevo);
        if (campo.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            // Cursor al final
            Bundle sel = new Bundle();
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, nuevo.length());
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, nuevo.length());
            campo.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel);
            return true;
        }

        // Plan B: portapapeles + pegar
        copiar((actual.isEmpty() ? "" : " ") + dicho);
        return campo.performAction(AccessibilityNodeInfo.ACTION_PASTE);
    }

    private void copiar(String t) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("dictado", t));
    }

    private static String mayusculaInicial(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }
}
