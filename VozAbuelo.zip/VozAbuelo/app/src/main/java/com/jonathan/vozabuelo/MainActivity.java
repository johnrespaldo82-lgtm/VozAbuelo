package com.jonathan.vozabuelo;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Pantalla de configuración: dar permiso de micrófono y activar la burbuja. */
public class MainActivity extends Activity {

    private TextView estado;
    private Button btnMic, btnAcc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int pad = dp(24);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad * 2, pad, pad);

        TextView titulo = texto("🎤 Voz Abuelo", 30);
        titulo.setGravity(Gravity.CENTER);
        col.addView(titulo);

        col.addView(texto("Cuando vayas a escribir, aparece una burbuja azul. "
                + "Tócala, habla, y lo que digas se escribe solo. "
                + "Tócala otra vez para terminar antes.", 18));

        estado = texto("", 20);
        estado.setPadding(0, dp(24), 0, dp(16));
        col.addView(estado);

        btnMic = boton("1. Dar permiso de micrófono");
        btnMic.setOnClickListener(v ->
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1));
        col.addView(btnMic);

        btnAcc = boton("2. Activar la burbuja");
        btnAcc.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        col.addView(btnAcc);

        col.addView(texto("Si al activarla dice \"Configuración restringida\": "
                + "toca el botón de abajo → los 3 puntitos (⋮) arriba a la derecha → "
                + "\"Permitir configuración restringida\". Luego vuelve al paso 2.", 15));

        Button btnInfo = boton("Abrir información de la app");
        btnInfo.setOnClickListener(v -> startActivity(new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))));
        col.addView(btnInfo);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFFFFFFFF);
        sv.addView(col);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        actualizar();
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] p, int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        actualizar();
    }

    private void actualizar() {
        boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
        boolean acc = servicioActivo();
        btnMic.setEnabled(!mic);
        btnAcc.setText(acc ? "Burbuja activada ✔ (abrir ajustes)" : "2. Activar la burbuja");

        if (mic && acc) {
            estado.setText("✅ Todo listo. Abre WhatsApp, toca donde se escribe y verás la burbuja.");
            estado.setTextColor(0xFF2E7D32);
        } else {
            estado.setText((mic ? "✔" : "✘") + " Micrófono\n" + (acc ? "✔" : "✘") + " Burbuja");
            estado.setTextColor(0xFFC62828);
        }
    }

    private boolean servicioActivo() {
        String activos = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(activos)) return false;
        ComponentName yo = new ComponentName(this, VozService.class);
        for (String s : activos.split(":")) {
            ComponentName c = ComponentName.unflattenFromString(s);
            if (yo.equals(c)) return true;
        }
        return false;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private TextView texto(String t, float sp) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        tv.setTextColor(0xFF212121);
        tv.setPadding(0, dp(8), 0, dp(8));
        return tv;
    }

    private Button boton(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(72));
        lp.topMargin = dp(12);
        b.setLayoutParams(lp);
        return b;
    }
}
