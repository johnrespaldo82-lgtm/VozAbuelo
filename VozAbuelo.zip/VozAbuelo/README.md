# Voz Abuelo 🎤

Burbuja flotante que aparece cuando hay un campo para escribir (WhatsApp, mensajes, Google, etc.).
Se toca, se habla, y el texto se escribe solo en el campo.

## Cómo funciona
- **Servicio de accesibilidad**: detecta cuándo hay un campo de texto activo, muestra la burbuja y escribe el texto en él.
- **SpeechRecognizer** de Android (motor de Google), en español de México (`es-MX`).
- Burbuja azul = lista · Roja = escuchando · Se puede arrastrar a otro lado.
- Toque 1: empieza a escuchar. Se detiene sola al dejar de hablar, o con un segundo toque.
- El texto que va entendiendo se ve en una etiqueta junto a la burbuja.

## Opción A: compilar con GitHub (sin instalar nada)
1. Crea un repositorio nuevo en GitHub y sube todo el contenido de esta carpeta.
2. Pestaña **Actions** → espera a que termine "Compilar APK" (≈4 min).
3. Abre la ejecución → sección **Artifacts** → descarga `VozAbuelo-apk` (es un .zip con el `app-debug.apk`).

## Opción B: Android Studio
1. File → Open → selecciona la carpeta `VozAbuelo`.
2. Espera la sincronización de Gradle.
3. Build → Build App Bundle(s) / APK(s) → Build APK(s).
4. El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar en el teléfono del abuelo
1. Pasa el APK al teléfono e instálalo (aceptar "instalar apps de origen desconocido").
2. Abre **Voz Abuelo**:
   - Botón 1 → permitir micrófono.
   - Botón 2 → Accesibilidad → Voz Abuelo → activar.
3. **Android 13 o más nuevo**: si sale "Configuración restringida", ve a
   Ajustes → Apps → Voz Abuelo → ⋮ (arriba a la derecha) → **Permitir configuración restringida**, y repite el paso 2.
4. Requisitos: app de **Google** instalada/actualizada e internet (o descargar el paquete de voz en español sin conexión en
   Ajustes → Google → Voz / Reconocimiento de voz sin conexión).

## Notas
- Algunos fabricantes (Xiaomi, Huawei, Oppo) apagan servicios en segundo plano: quita la optimización de batería a "Voz Abuelo".
- Si una app no deja escribir directo, el texto se copia y se intenta pegar; si no, queda en el portapapeles.
- Para cambiar idioma, edita `IDIOMA` en `VozService.java`.
